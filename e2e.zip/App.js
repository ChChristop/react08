import React, { useState, useReducer, useRef, useLayoutEffect } from 'react';
import './App.css';

function App() {
  const [word, setWord] = useState('');
  const [his, setHis] = useReducer((prev, cur) => [...prev, cur], []);
  const [curWord, setCurword] = useState('');
  const inputWord = useRef();

  function oninput(e) {
    setWord(e.target.value);
  }

  function setHistory() {
    setHis(word);
    setCurword(word);
    setWord('');
  }

  useLayoutEffect(() => {
    inputWord.current.focus();
  });

  return (
    <div className="container">
      <div className="history">{his.join('-')}</div>
      <p className="curWord"> {curWord}</p> <br />
      <input ref={inputWord} type="text" onInput={oninput} value={word} />
      <button onClick={setHistory}>제출</button>
    </div>
  );
}

export default App;
